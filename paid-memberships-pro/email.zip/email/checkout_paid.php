<p>Thank you for joining Daric Bennett's Bass Nation! Your Free Trial is officially active!</p> 

<p>Below are details about your membership and a receipt for your completed transaction.</p>

<p>Account: !!display_name!! (!!user_email!!)</p>
<p>Membership Level: !!membership_level_name!!</p>
<p>Membership Fee: !!membership_cost!!</p>
!!membership_expiration!! !!discount_code!!

<p>
	Invoice #!!invoice_id!! on !!invoice_date!!<br />
	Total Billed: !!invoice_total!!
</p>
<p>
	Billing Information:<br />
	!!billing_address!!
</p>

<p>
	!!cardtype!!: !!accountnumber!!<br />
	Expires: !!expirationmonth!!/!!expirationyear!!
</p>

<p>Log in to your account by following the link below:</p> 
<p>!!login_link!!</p>